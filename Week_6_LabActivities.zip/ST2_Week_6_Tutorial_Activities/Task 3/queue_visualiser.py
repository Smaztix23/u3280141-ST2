import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
CANVAS_WIDTH = 500
CANVAS_HEIGHT = 300

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Queue Value:").grid(row=0, column=0)
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)

        queue_btn = tk.Button(control_frame, text="Queue", command=self.queue_value)
        queue_btn.grid(row=0, column=2, padx=5)

        dequeue_btn = tk.Button(control_frame, text="Dequeue", command=self.dequeue_value)
        dequeue_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
                                     fill="lightblue", outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2,
                                text=str(data), font=("Arial", 16))

    def draw_queue(self):
        self.canvas.delete("all")
        x = 20
        y = CANVAS_HEIGHT // 2 - NODE_HEIGHT // 2

        for val in self.queue:
            self.draw_node(x, y, val)
            x += NODE_WIDTH + 10

        if self.queue:
            self.canvas.create_text(40, y - 20, text="Front", font=("Arial", 12), fill="red")
            self.canvas.create_text(
                x - NODE_WIDTH - 10 + NODE_WIDTH // 2,
                y + NODE_HEIGHT + 20,
                text="Rear",
                font=("Arial", 12),
                fill="red"
            )

    def queue_value(self):
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to queue.")
            return

        self.queue.append(val)
        self.push_entry.delete(0, tk.END)
        self.status_label.config(text=f"queued {val} into queue")
        self.draw_queue()

    def dequeue_value(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return

        val = self.queue.pop(0)
        self.status_label.config(text=f"Dequeued {val} from queue")
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    root.mainloop()