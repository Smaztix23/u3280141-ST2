import time
import random
import string
import matplotlib.pyplot as plt



# BST

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left

            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root


# AVL
class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        t3 = y.right

        y.right = z
        z.left = t3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        t2 = y.left

        y.left = z
        z.right = t2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left

            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if root is None:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)


# RED-BLACK TREE

RED = "red"
BLACK = "black"


class RBNode:
    def __init__(self, name=None, phone=None, color=RED):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.nil = RBNode(color=BLACK)
        self.root = self.nil

    def search(self, node, name):
        while node != self.nil and name != node.name:
            if name < node.name:
                node = node.left
            else:
                node = node.right
        return None if node == self.nil else node

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.nil:
            y.left.parent = x

        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right
        if x.right != self.nil:
            x.right.parent = y

        x.parent = y.parent
        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x

        x.right = y
        y.parent = x

    def insert(self, _unused_root, name, phone):
        node = RBNode(name, phone, RED)
        node.left = self.nil
        node.right = self.nil

        parent = None
        current = self.root

        while current != self.nil:
            parent = current
            if node.name < current.name:
                current = current.left
            elif node.name > current.name:
                current = current.right
            else:
                current.phone = phone
                return self.root

        node.parent = parent

        if parent is None:
            self.root = node
        elif node.name < parent.name:
            parent.left = node
        else:
            parent.right = node

        if node.parent is None:
            node.color = BLACK
            return self.root

        if node.parent.parent is None:
            return self.root

        self.fix_insert(node)
        return self.root

    def fix_insert(self, k):
        while k.parent and k.parent.color == RED:
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)

            if k == self.root:
                break

        self.root.color = BLACK

    def transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def minimum(self, node):
        while node.left != self.nil:
            node = node.left
        return node

    def delete(self, _unused_root, name):
        z = self.search(self.root, name)
        if z is None:
            return self.root

        y = z
        y_original_color = y.color

        if z.left == self.nil:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.nil:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right

            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y

            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        if y_original_color == BLACK:
            self.fix_delete(x)

        return self.root

    def fix_delete(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                s = x.parent.right
                if s.color == RED:
                    s.color = BLACK
                    x.parent.color = RED
                    self.left_rotate(x.parent)
                    s = x.parent.right

                if s.left.color == BLACK and s.right.color == BLACK:
                    s.color = RED
                    x = x.parent
                else:
                    if s.right.color == BLACK:
                        s.left.color = BLACK
                        s.color = RED
                        self.right_rotate(s)
                        s = x.parent.right

                    s.color = x.parent.color
                    x.parent.color = BLACK
                    s.right.color = BLACK
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                s = x.parent.left
                if s.color == RED:
                    s.color = BLACK
                    x.parent.color = RED
                    self.right_rotate(x.parent)
                    s = x.parent.left

                if s.right.color == BLACK and s.left.color == BLACK:
                    s.color = RED
                    x = x.parent
                else:
                    if s.left.color == BLACK:
                        s.right.color = BLACK
                        s.color = RED
                        self.left_rotate(s)
                        s = x.parent.left

                    s.color = x.parent.color
                    x.parent.color = BLACK
                    s.left.color = BLACK
                    self.right_rotate(x.parent)
                    x = self.root

        x.color = BLACK


# =========================================================
# BENCHMARK
# =========================================================

def benchmark_three_trees(n=1000, search_fraction=0.5, delete_count=100):
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    search_names = random.sample(names, int(n * search_fraction)) + ['notfoundname'] * int(n * (1 - search_fraction))
    delete_names = random.sample(names, min(delete_count, n))

    # BST
    bst = BST()
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert = time.time() - start

    start = time.time()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search = time.time() - start

    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete = time.time() - start

    # AVL
    avl = AVLTree()
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert = time.time() - start

    start = time.time()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search = time.time() - start

    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete = time.time() - start

    # Red-Black
    rb = RedBlackTree()
    start = time.time()
    for i in range(n):
        rb.insert(rb.root, names[i], phones[i])
    rb_insert = time.time() - start

    start = time.time()
    found_rb = sum(1 for name in search_names if rb.search(rb.root, name))
    rb_search = time.time() - start

    start = time.time()
    for name in delete_names:
        rb.delete(rb.root, name)
    rb_delete = time.time() - start

    print(f"\nBenchmarking with {n} entries:\n")
    print("Operation      BST         AVL         Red-Black")
    print("---------------------------------------------------")
    print(f"Insertions:    {bst_insert:.6f}    {avl_insert:.6f}    {rb_insert:.6f}")
    print(f"Searches:      {bst_search:.6f}    {avl_search:.6f}    {rb_search:.6f}")
    print(f"Deletions:     {bst_delete:.6f}    {avl_delete:.6f}    {rb_delete:.6f}")
    print("---------------------------------------------------")
    print(f"Found count:   BST={found_bst}, AVL={found_avl}, RB={found_rb}")

    return {
        "BST": (bst_insert, bst_search, bst_delete, found_bst),
        "AVL": (avl_insert, avl_search, avl_delete, found_avl),
        "RB": (rb_insert, rb_search, rb_delete, found_rb),
    }


def plot_three_tree_benchmarks(sizes):
    bst_insert, bst_search, bst_delete = [], [], []
    avl_insert, avl_search, avl_delete = [], [], []
    rb_insert, rb_search, rb_delete = [], [], []

    for n in sizes:
        result = benchmark_three_trees(n=n, search_fraction=0.5, delete_count=min(100, n))

        bst_insert.append(result["BST"][0])
        bst_search.append(result["BST"][1])
        bst_delete.append(result["BST"][2])

        avl_insert.append(result["AVL"][0])
        avl_search.append(result["AVL"][1])
        avl_delete.append(result["AVL"][2])

        rb_insert.append(result["RB"][0])
        rb_search.append(result["RB"][1])
        rb_delete.append(result["RB"][2])

    plt.figure(figsize=(12, 8))

    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_insert, label="BST Insert")
    plt.plot(sizes, avl_insert, label="AVL Insert")
    plt.plot(sizes, rb_insert, label="RB Insert")
    plt.title("Insertion Time vs Input Size")
    plt.ylabel("Time (s)")
    plt.legend()

    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_search, label="BST Search")
    plt.plot(sizes, avl_search, label="AVL Search")
    plt.plot(sizes, rb_search, label="RB Search")
    plt.title("Search Time vs Input Size")
    plt.ylabel("Time (s)")
    plt.legend()

    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_delete, label="BST Delete")
    plt.plot(sizes, avl_delete, label="AVL Delete")
    plt.plot(sizes, rb_delete, label="RB Delete")
    plt.title("Deletion Time vs Input Size")
    plt.xlabel("Number of Nodes")
    plt.ylabel("Time (s)")
    plt.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    benchmark_three_trees(n=1000)

    sizes_to_test = [1000, 5000, 10000]
    plot_three_tree_benchmarks(sizes_to_test)