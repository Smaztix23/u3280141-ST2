#TASK 2 
import tkinter as tk
from tkinter import messagebox
import time
import random
import string
from collections import deque


#contact node
class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


#BST contact directory
class ContactDirectory:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Contact(name, phone)

        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone

        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root

        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        return root

    def inorder(self, root, result=None):
        if result is None:
            result = []

        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)

        return result


#GUI
class BSTVisualizerApp:
    def __init__(self, root):
        self.directory = ContactDirectory()

        self.root = root
        self.root.title("Contact Directory BST")

        #input frame
        frame = tk.Frame(root)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0, padx=5)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1, padx=5)

        tk.Label(frame, text="Phone:").grid(row=1, column=0, padx=5)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1, padx=5)

        #buttons
        button_frame = tk.Frame(root)
        button_frame.pack()

        tk.Button(button_frame, text="Insert Contact", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(button_frame, text="Search Contact", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(button_frame, text="Delete Contact", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(button_frame, text="Show All Contacts", command=self.show_all).grid(row=0, column=3, padx=5)
        tk.Button(button_frame, text="Run Benchmark", command=self.benchmark).grid(row=0, column=4, padx=5)

        #output box
        self.output_text = tk.Text(root, height=10, width=60)
        self.output_text.pack(pady=10)

        #canvas
        self.canvas = tk.Canvas(root, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

    #functions

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Input Error", "Enter name and phone")
            return

        self.directory.root = self.directory.insert(self.directory.root, name, phone)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()

        if not name:
            messagebox.showwarning("Input Error", "Enter name")
            return

        node = self.directory.search(self.directory.root, name)

        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Not found\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()

        if not name:
            messagebox.showwarning("Input Error", "Enter name")
            return

        self.directory.root = self.directory.delete(self.directory.root, name)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)

        contacts = self.directory.inorder(self.directory.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts\n")
        else:
            for name, phone in contacts:
                self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    #trees

    def draw_tree(self):
        self.canvas.delete("all")

        if not self.directory.root:
            return

        self._draw_node(self.directory.root, 400, 20, 200)

    def _draw_node(self, node, x, y, offset):
        if node is None:
            return

        radius = 20

        if node.left:
            self.canvas.create_line(x, y, x - offset, y + 70)
            self._draw_node(node.left, x - offset, y + 70, offset // 2)

        if node.right:
            self.canvas.create_line(x, y, x + offset, y + 70)
            self._draw_node(node.right, x + offset, y + 70, offset // 2)

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill="lightblue")
        self.canvas.create_text(x, y, text=node.name)

    #benchmark

    def benchmark(self):
        self.directory.root = None

        N = 1000
        names = [''.join(random.choices(string.ascii_lowercase, k=7)) for _ in range(N)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(N)]

        start = time.time()
        for i in range(N):
            self.directory.root = self.directory.insert(self.directory.root, names[i], phones[i])
        insert_time = time.time() - start

        start = time.time()
        for name in names:
            self.directory.search(self.directory.root, name)
        search_time = time.time() - start

        start = time.time()
        for name in names[:100]:
            self.directory.root = self.directory.delete(self.directory.root, name)
        delete_time = time.time() - start

        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(
            tk.END,
            f"Insertion time: {insert_time:.4f}s\n"
            f"Search time: {search_time:.4f}s\n"
            f"Deletion time: {delete_time:.4f}s\n"
        )

        self.draw_tree()


if __name__ == "__main__":
    root = tk.Tk()
    app = BSTVisualizerApp(root)
    root.mainloop()