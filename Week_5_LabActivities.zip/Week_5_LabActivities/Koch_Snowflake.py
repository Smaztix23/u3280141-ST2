#Task 4

from tkinter import * 
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()  # Create a window
        window.title("Koch Snowflake")  #title

        self.width = 200
        self.height = 200

        self.canvas = Canvas(window,
                             width=self.width, height=self.height)
        self.canvas.pack()

        #add a label, an entry, and a button to frame1
        frame1 = Frame(window)  # Create and add a frame to window
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order,
              justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop()  #create event loop

    def display(self):
        self.canvas.delete("line")

        order = int(self.order.get())

        #points are ordered clockwise
        p1 = [self.width / 2, 10]                  
        p2 = [self.width - 20, self.height - 50]  
        p3 = [20, self.height - 50]               

        #Draw koch curve on each side of the triangle
        self.displayKoch(order, p1, p2)
        self.displayKoch(order, p2, p3)
        self.displayKoch(order, p3, p1)

    def displayKoch(self, order, p1, p2):
        if order == 0:  #Base condition
            self.drawLine(p1, p2)
        else:
            #Divide line into 3 equal parts
            pA = self.oneThird(p1, p2)
            pB = self.twoThird(p1, p2)

            #Peak of the outward triangle
            pC = self.peakPoint(pA, pB)

            #Recursively draw the 4 segments
            self.displayKoch(order - 1, p1, pA)
            self.displayKoch(order - 1, pA, pC)
            self.displayKoch(order - 1, pC, pB)
            self.displayKoch(order - 1, pB, p2)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags="line")

    def oneThird(self, p1, p2):
        p = [0, 0]
        p[0] = p1[0] + (p2[0] - p1[0]) / 3
        p[1] = p1[1] + (p2[1] - p1[1]) / 3
        return p

    def twoThird(self, p1, p2):
        p = [0, 0]
        p[0] = p1[0] + 2 * (p2[0] - p1[0]) / 3
        p[1] = p1[1] + 2 * (p2[1] - p1[1]) / 3
        return p

    def peakPoint(self, p1, p2):
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]

        #had to rotate by -60 degrees 
        p = [0, 0]
        p[0] = p1[0] + dx * math.cos(-math.pi / 3) - dy * math.sin(-math.pi / 3)
        p[1] = p1[1] + dx * math.sin(-math.pi / 3) + dy * math.cos(-math.pi / 3)
        return p

KochSnowflake()  #Create GUI