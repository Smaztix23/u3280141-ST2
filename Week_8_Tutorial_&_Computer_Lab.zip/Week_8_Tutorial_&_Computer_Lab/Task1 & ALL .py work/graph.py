class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                self.graph[vertex2].append(vertex1)

                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]

            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)

        if not self.directed:
            if vertex2 in self.graph and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)

    def print_graph(self):
        for vertex in self.graph:
            print(vertex, "->", self.graph[vertex])


    def bfs(self, start):
        visited = []
        queue = [start]

        while queue:
            vertex = queue.pop(0)
            if vertex not in visited:
                visited.append(vertex)
                for neighbour in self.graph[vertex]:
                    if neighbour not in visited:
                        queue.append(neighbour)

        return visited
    
    def dfs(self, start):
        visited = []
        stack = [start]

        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.append(vertex)
                for neighbour in reversed(self.graph[vertex]):
                    if neighbour not in visited:
                        stack.append(neighbour)

        return visited
    
    def has_undirected_cycle(self):
        visited = set()

        def dfs(vertex, parent):
            visited.add(vertex)

            for neighbour in self.graph[vertex]:
                if neighbour not in visited:
                    if dfs(neighbour, vertex):
                        return True
                elif neighbour != parent:
                    return True

            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True

        return False