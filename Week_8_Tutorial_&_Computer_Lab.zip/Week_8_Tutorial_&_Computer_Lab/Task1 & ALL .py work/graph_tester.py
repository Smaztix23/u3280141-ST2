from graph import Graph

# === Undirected Graph ===
print("Undirected Graph:")
g = Graph()

for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

g.print_graph()
print()

"""# === Directed Graph ===
print("Directed Graph:")
g = Graph(directed=True)

for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

g.print_graph()
print()

# === Weighted Graph ===
print("Weighted Directed Graph:")
g = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

g.add_edge('A', 'B', 10)
g.add_edge('B', 'C', 20)
g.add_edge('C', 'D', 30)

g.print_graph()
print()

# === Removal Test ===
print("Removal Test:")
removal_test = Graph()

for v in ['A', 'B', 'C', 'D']:
    removal_test.add_vertex(v)

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')

removal_test.print_graph()
print("After removing edge A-B:")

removal_test.remove_edge('A', 'B')
removal_test.print_graph()

print("After removing vertex C:")
removal_test.remove_vertex('C')
removal_test.print_graph()"""

# ===== TASK 2: BFS =====
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)


# ===== TASK 3: DFS =====
print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

# ===== TASK 4: CYCLE DETECTION =====
print("\n--- CYCLE DETECTION TEST ---")

# Graph WITH a cycle
cycle_graph = Graph()

for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)

cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # forms cycle

print("Cycle graph:")
cycle_graph.print_graph()
print("Has cycle?", cycle_graph.has_undirected_cycle())

# Graph WITHOUT a cycle
acyclic_graph = Graph()

for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)

acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("\nAcyclic graph:")
acyclic_graph.print_graph()
print("Has cycle?", acyclic_graph.has_undirected_cycle())

# ===== TASK 5: WEIGHTED DIRECTED GRAPH =====
print("\n--- WEIGHTED DIRECTED GRAPH ---")

wg = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

wg.print_graph()

print("Weights:")
for edge in wg.weights:
    print(edge, "->", wg.weights[edge])