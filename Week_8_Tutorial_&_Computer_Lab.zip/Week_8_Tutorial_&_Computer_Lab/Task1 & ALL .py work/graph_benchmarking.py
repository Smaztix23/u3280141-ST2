from graph import Graph
import time
import random


def benchmark_graph_operations(num_vertices, num_edges):
    g = Graph()

    # Time adding vertices
    start_time = time.time()
    for i in range(num_vertices):
        g.add_vertex(str(i))
    vertex_time = time.time()
    vertex_duration = vertex_time - start_time

    # Time adding edges
    edges_added = 0
    for _ in range(num_edges):
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))
        if v1 != v2:
            g.add_edge(v1, v2)
            edges_added += 1
    edge_time = time.time()
    edge_duration = edge_time - vertex_time

    # Time BFS
    if '0' in g.graph:
        bfs_start = time.time()
        g.bfs('0')
        bfs_end = time.time()
        bfs_duration = bfs_end - bfs_start
    else:
        bfs_duration = 0

    # Time DFS
    if '0' in g.graph:
        dfs_start = time.time()
        g.dfs('0')
        dfs_end = time.time()
        dfs_duration = dfs_end - dfs_start
    else:
        dfs_duration = 0

    print(f"\nGraph with {num_vertices} vertices and about {edges_added} edges")
    print(f"Add vertices time: {vertex_duration:.6f} seconds")
    print(f"Add edges time:    {edge_duration:.6f} seconds")
    print(f"BFS time:          {bfs_duration:.6f} seconds")
    print(f"DFS time:          {dfs_duration:.6f} seconds")


if __name__ == "__main__":
    benchmark_graph_operations(10, 20)
    benchmark_graph_operations(100, 200)
    benchmark_graph_operations(1000, 3000)