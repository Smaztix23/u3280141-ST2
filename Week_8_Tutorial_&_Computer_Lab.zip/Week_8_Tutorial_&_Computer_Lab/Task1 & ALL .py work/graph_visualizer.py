from graph import Graph
import tkinter as tk
import math
from tkinter import simpledialog


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph

        self.canvas = tk.Canvas(self, width=400, height=400, bg='white')
        self.canvas.pack()

        self.vertex_positions = {}
        self.vertex_items = {}

        # Buttons
        button_frame = tk.Frame(self)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Run BFS", command=self.run_bfs).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Run DFS", command=self.run_dfs).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Add Vertex", command=self.add_vertex).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Remove Vertex", command=self.remove_vertex).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Add Edge", command=self.add_edge).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Remove Edge", command=self.remove_edge).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Undirected Cycle", command=self.detect_undirected_cycle).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Directed Cycle", command=self.detect_directed_cycle).pack(side=tk.LEFT, padx=5)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions = {}
        self.vertex_items = {}

        radius = 20
        spacing = 100

        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 200, 200

        # Arrange vertices in a circle
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)

            oval = self.canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius,
                fill='lightblue'
            )
            text = self.canvas.create_text(x, y, text=v)
            self.vertex_items[v] = (oval, text)

        # Draw edges
        drawn_edges = set()
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                if not self.graph.directed:
                    edge_key = tuple(sorted((v, nbr)))
                    if edge_key in drawn_edges:
                        continue
                    drawn_edges.add(edge_key)

                self.canvas.create_line(
                    x1, y1, x2, y2,
                    arrow=tk.LAST if self.graph.directed else None
                )

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")

    def highlight_order(self, order, index=0):
        if index >= len(order):
            return

        vertex = order[index]
        oval, text = self.vertex_items[vertex]
        self.canvas.itemconfig(oval, fill='yellow')

        self.after(700, lambda: self.highlight_order(order, index + 1))

    def run_bfs(self):
        if not self.graph.graph:
            return
        start = next(iter(self.graph.graph))
        self.draw_graph()
        order = self.graph.bfs(start)
        self.highlight_order(order)

    def run_dfs(self):
        if not self.graph.graph:
            return
        start = next(iter(self.graph.graph))
        self.draw_graph()
        order = self.graph.dfs(start)
        self.highlight_order(order)

    def add_vertex(self):
        v = simpledialog.askstring("Add Vertex", "Enter vertex name:")
        if v:
            self.graph.add_vertex(v)
            self.draw_graph()


    def remove_vertex(self):
        v = simpledialog.askstring("Remove Vertex", "Enter vertex name:")
        if v:
            self.graph.remove_vertex(v)
            self.draw_graph()


    def add_edge(self):
        v1 = simpledialog.askstring("Add Edge", "Enter first vertex:")
        v2 = simpledialog.askstring("Add Edge", "Enter second vertex:")

        if v1 and v2:
            if self.graph.weighted:
                w = simpledialog.askinteger("Weight", "Enter weight:")
                if w is None:
                    w = 0
                self.graph.add_edge(v1, v2, w)
            else:
                self.graph.add_edge(v1, v2)

            self.draw_graph()


    def remove_edge(self):
        v1 = simpledialog.askstring("Remove Edge", "Enter first vertex:")
        v2 = simpledialog.askstring("Remove Edge", "Enter second vertex:")

        if v1 and v2:
            self.graph.remove_edge(v1, v2)
            self.draw_graph()

    def highlight_cycle(self, cycle_nodes):
        self.draw_graph()
        for vertex in cycle_nodes:
            if vertex in self.vertex_items:
                oval, text = self.vertex_items[vertex]
                self.canvas.itemconfig(oval, fill='red')


    def detect_undirected_cycle(self):
        if self.graph.directed:
            print("Use an undirected graph for this button.")
            return

        visited = set()

        def dfs(vertex, parent, path):
            visited.add(vertex)
            path.append(vertex)

            for neighbour in self.graph.graph[vertex]:
                if neighbour not in visited:
                    result = dfs(neighbour, vertex, path.copy())
                    if result:
                        return result
                elif neighbour != parent:
                    if neighbour in path:
                        cycle_start = path.index(neighbour)
                        return path[cycle_start:] + [neighbour]

            return None

        for vertex in self.graph.graph:
            if vertex not in visited:
                cycle = dfs(vertex, None, [])
                if cycle:
                    self.highlight_cycle(cycle)
                    print("Undirected cycle found:", cycle)
                    return

        print("No undirected cycle found.")


    def detect_directed_cycle(self):
        if not self.graph.directed:
            print("Use a directed graph for this button.")
            return

        visited = set()
        rec_stack = set()

        def dfs(vertex, path):
            visited.add(vertex)
            rec_stack.add(vertex)
            path.append(vertex)

            for neighbour in self.graph.graph[vertex]:
                if neighbour not in visited:
                    result = dfs(neighbour, path.copy())
                    if result:
                        return result
                elif neighbour in rec_stack:
                    if neighbour in path:
                        cycle_start = path.index(neighbour)
                        return path[cycle_start:] + [neighbour]

            rec_stack.remove(vertex)
            return None

        for vertex in self.graph.graph:
            if vertex not in visited:
                cycle = dfs(vertex, [])
                if cycle:
                    self.highlight_cycle(cycle)
                    print("Directed cycle found:", cycle)
                    return

        print("No directed cycle found.")


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    app = GraphVisualizer(g)
    app.mainloop()